const flag = "RicSec{}";
export default flag;